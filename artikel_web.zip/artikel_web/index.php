<!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
       <link rel="stylesheet" type="text/css" href="animasi/animate.min.css">
       <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">

      <link rel="stylesheet" type="text/css" href="style.css">

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

      <title>Heloo Read</title>
    </head>

    <body id="home" class="scrollspy">


    <div class="navbar-fixed">
      <nav class=" blue-grey">
        <div class="container">
          <div class="nav-wrapper">
            <a href="#home" class="brand-logo">Artikel</a>
            <a href="#" data-target="mobile-nav" class="sidenav-trigger"><i class="material-icons">menu</i></a>
            <ul class="right hide-on-med-and-down">
               <li class="active"><a href="#home">Home</a></li>
              <li><a href="#about">About Us</a></li>
              <li><a href="#portfolio">Tokoh</a></li>
              <li><a href="#contact">Contact Us</a></li>
            </ul>
          </div>
        </div>
      </nav>
  </div>


  <ul class="sidenav" id="mobile-nav">
    <li><a href="#home"><i class="material-icons blue-text">home</i>Home</a></li>
    <li><a href="#about">About Us</a></li>
    <li><a href="#portfolio">Tokoh</a></li>
    <li><a href="#contact">Contact Us</a></li>
    <li><a href=""><i class="material-icons black-text">keyboard_tab</i>Logout</a></li>
  </ul>      


  <div class="slider">
    <ul class="slides">
      <li>
        <img class="responsive-img" src="img/a.jpg">
        <div class="caption left-align">
          <h3>Left Aligned Caption</h3>
          <h5 class="light grey-text text-lighten-3">Here's our small slogan</h5>
        </div>
      </li>
      <li>
        <img class="responsive-img" src="img/e.jpg">
        <div class="caption right-align">
          <h3>Right Aligned Caption</h3>
          <h5 class="light grey-text text-lighten-3">Here's our small slogan</h5>
        </div>
      </li>
      <li>
        <img class="responsive-img" src="img/d.jpg">
        <div class="caption center-align">
          <h3>This our Big Tagline</h3>
          <h5 class="light grey-text text-lighten-3">Here's our small slogan</h5>
        </div>
      </li>
    </ul>
  </div>
  <div class="card-panel grey lighten-3">
    <div class="container">
      <div class="isi-dalam"></div>
      <h1 class="center light">Makanan Minuman Cafe dan Resto</h1>
<?php 
include 'admin/koneksi.php';
$sql=mysqli_query($koneksi,"SELECT * FROM tb_sejarah");
while ($r=mysqli_fetch_array($sql)) { ?>      
  
    <img src="admin/img/<?php echo $r['foto']; ?>" width=100%>

    <h2 style="font-size: 20px;"><?php echo $r['judul']; ?></h2>
    <?php echo $r['deskripsi']; ?>
    
<?php  }
?>    
  </div>
  </div>
  <section id="portfolio" class="portfolio scrollspy">
    <div class="container">
      <h3 class="center">Portofolio</h3>
      <div class="row">
        <div class="col m3 s12">
          <img src="img/f.jpg" class="responsive-img materialboxed">
        </div>
        <div class="col m3 s12">
          <img src="img/g.jpg" class="responsive-img materialboxed">
        </div>
        <div class="col m3 s12">
          <img src="img/h.jpg" class="responsive-img materialboxed">
        </div>
        <div class="col m3 s12">
          <img src="img/i.jpg" class="responsive-img materialboxed">
        </div>
      </div>
      <div class="row">
        <div class="col m3 s12">
          <img src="img/j.jpg" class="responsive-img materialboxed">
        </div>
        <div class="col m3 s12">
          <img src="img/k.jpg" class="responsive-img materialboxed">
        </div>
        <div class="col m3 s12">
          <img src="img/l.jpg" class="responsive-img materialboxed">
        </div>
        <div class="col m3 s12">
          <img src="img/h.jpg" class="responsive-img materialboxed">
        </div>
      </div>
    </div>
  </section>


  <section id="about" class="about scrollspy">
    <div class="container">
      <div class="row">
        <h3 class="center"> About Us</h3>
        <div class="tada col m6 light"  >
          <h5>We Are Professional</h5>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
          quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
          consequat. </p>
        </div>
      </div>
    </div>
  </section>a

  <section id="team" class="team grey lighten-5">
    <div class="container">
      <div class="row">
        <h2 class="center">Meet Our Team</h2>
        <p class="center">Lorem ipsum dolor sit amet, consectetur adipisicing elit sed do eiusmod
        tempor.</p>
        <div class="col m3 wow fadeInLeft" data-wow-delay="3.4s">
          <div class="team-member center">
            <img src="img/1.jpg" class="responsive-img circle">
            <h5 class="light">Geri Rahmattul Hakim</h5>
            <b>Member</b>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
          </div>
        </div>
        <div class="col m3 wow fadeInLeft" data-wow-delay="2.8s">
          <div class="team-member center">
            <img src="img/1.jpg" class="responsive-img circle">
            <h5 class="light">M.Rizki</h5>
            <b>Member</b>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
          </div>
        </div>
        <div class="col m3 wow fadeInLeft" data-wow-delay="2.4s">
          <div class="team-member center">
            <img src="img/1.jpg" class="responsive-img circle">
            <h5 class="light">M.A.P Edwin</h5>
            <b>Member</b>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
          </div>
        </div>
        <div class="col m3 wow fadeInLeft" data-wow-delay="2s">
          <div class="team-member center">
            <img src="img/1.jpg" class="responsive-img circle">
            <h5 class="light">Aqil Rahman</h5>
            <b>Member</b>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- contact us -->

  <section>
    <div id="contact" class="contact grey lighten-3 scrollspy">
      <div class="container">
        <h3 class="center">Contact Us</h3>
        <div class="row">
          <div class="col m5 s12">
            <div class="card-panel cyan accent-4 center white-text">
              <i class="material-icons">email</i>
              <h5>Contact Us</h5>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.
              </p>
            </div>
            <ul class="collection width-header">
              <li class="collection-header light "><h4>Our Office</h4></li>
              <li class="collection-item">Artickel Web</li>
              <li class="collection-item">Jl.Raya Payakumbuh Lintau KM 18, Alang Laweh Halaban </li>
              <li class="collection-item">West Sumatra, indonesia</li>
            </ul>
          </div>


           <div class="col m7 s12">
          <form>
            <div class="card-panel light ">
              <h5>Please Fill this form</h5>
              <div class="input-field">
                <input type="text" name="name" id="name" required="" >
                <label for="name">Name</label>
              </div>
              <div class="input-field">
                <input type="email" name="email" id="email" class="valide">
                <label for="email">Email</label>
              </div>
              <div class="input-field">
                <input type="text" name="phone" id="phone">
                <label for="phone">Phone Number</label>
              </div>
              <div class="input-field">
               <textarea name="message" id="message" class="materialize-textarea"></textarea>
                <label for="message">message</label>
              </div>
              <button type="submit" class="btn cyan accent-4 ">Send</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>


  <footer class="page-footer blue-grey darken-4 white-text">
          <div class="container">
            <div class="row">
              <div class="col l6 s12">
                <h5 class="light">CONTACT</h5>
                <ul>
                  <p><a href="#!"><i class="material-icons white-text">email</i></a> gerirahmat19@gmail.com</p>
                   <p><a href="#!"><i class="material-icons white-text">store_mall_directory</i></a> KM 18 Main Street, Halaban, 26262</p>
                  <p><a href="#!"><i class="material-icons white-text">local_phone</i></a>  091270615411</p>
                </ul>
              </div>
              <div class="col l4 offset-l2 s12">
                <h5 class="light">Follow my akun social media</h5>
                <p>follow us on social media for special</p>
                <ul class="white">
                  <a href="#!"><i class="fab fa-facebook fa-2x blue-text text-darken-4 lbr"></i></a>
                  <a href="#!"><i class="fab fa-google-plus fa-2x red-text lbr"></i></a>
                  <a href="#!"><i class="fab fa-steam fa-2x light-blue-text text-darken-4 lbr"></i></a>
                  <a href="#!"><i class="fab fa-youtube fa-2x red-text lbr"></i></a>
                  <a href="#!"><i class="fab fa-telegram fa-2x blue-text lbr"></i></a>
                </ul>
              </div>
            </div>
          </div>
          <div class="footer-copyright white-text blue-grey darken-3">
            <div class="wow fadeInLeft container center" data-wow-delay="2s">
           | © 2018 Copyright Geri Rahmattul Hakim | 
            </div>
          </div>
    </footer>




      <!--JavaScript at end of body for optimized loading-->
      <script type="text/javascript" src="js/materialize.min.js"></script>
      <script src="js/wow.min.js"></script>
      <script>
      new WOW().init();
      </script>
      <script>
        const sidenav = document.querySelectorAll('.sidenav');
        M.Sidenav.init(sidenav);
      </script>

      <script>
        const slider = document.querySelectorAll('.slider');
        M.Slider.init(slider, {
          indicators: false,
          height: 500,
          transition: 600,
          interval: 3000
        });

        const parallax = document.querySelectorAll('.parallax');
        M.Parallax.init(parallax);

        const materialbox = document.querySelectorAll('.materialboxed');
        M.Materialbox.init(materialbox);

        const scroll = document.querySelectorAll('.scrollspy');
        M.ScrollSpy.init(scroll, {
          scrollOffset: 90
        });

      </script>
    </body>
  </html>
          