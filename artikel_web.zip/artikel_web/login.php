<?php 
	include "admin/koneksi.php";
 ?>
 <center>
 	<h2>Login Disini</h2>
 	<form method="POST" action="">
 		<table border="4">
 			<tr>
 				<td>Masukkan Username</td>
 				<td>:</td>
 				<td><input type="text" name="username"></td>
 			</tr>
 			<tr>
 				<td>Masukkan Password</td>
 				<td>:</td>
 				<td><input type="password" name="password"></td>
 			</tr>
 			<tr><td colspan="3"><center><input type="submit" name="login" value="Login"></center></td></tr>
 		</table>
 	</form>
 </center>
<?php 
if(isset($_POST['login'])){
	$username=(htmlentities($_POST['username']));
	$password=(htmlentities(md5($_POST['password'])));

	$sql=mysqli_query($koneksi,"SELECT * FROM tb_user WHERE username='$username' AND password='$password'");
	$cek=mysqli_num_rows($sql);

	if($cek>0){
		session_start();
		$_SESSION['username']=$username;
		echo "<script>alert('Anda Berhasil login')</script>";
		echo "<script>location='admin/index.php';</script>";
	}
	else{
		echo "<script>alert('Anda Gagal login')</script>";
	}
}

 ?>