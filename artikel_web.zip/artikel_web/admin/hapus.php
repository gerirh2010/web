<?php
session_start();
if (!isset($_SESSION['username'])) {
	header('location:../login.php');
}
include "koneksi.php";
$delete=mysqli_query($koneksi, "DELETE FROM tb_sejarah WHERE id='".$_GET['id']."'");
if ($delete) {
	echo "<script>alert('Anda Yakin Untuk Menghapus ?')</script>";
	echo "<script>location='index.php'</script>";
}
else{
	echo "Gagal";
} ?>