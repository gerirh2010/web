<?php
session_start();
if (!isset($_SESSION['username'])) {
	header('location:../login.php');
}
include "koneksi.php";
 ?>
<center>
	<h2>Data Artikel</h2>
	<a href="input.php">Input</a>||
	<a href="../logout.php">Logout</a>
	<table border="4">
		<tr>
			<td>No</td>
			<td>Judul Artikel</td>
			<td>Deskripsi</td>
			<td>Gambar</td>
			<td>Opsi</td>
<?php 
$no=1;
$sql=mysqli_query($koneksi,"SELECT * FROM tb_sejarah");
while ($r=mysqli_fetch_array($sql)) { ?>			
	<tr>
		<td><?php echo $no++; ?></td>
		<td><?php echo $r['judul']; ?></td>
		<td><?php echo $r['deskripsi']; ?></td>
		<td><img src="img/<?php echo $r['foto']; ?>" width=100></td>
		<td>
			<a href="edit.php?id=<?php echo $r['id']; ?>">Edit</a>||
			<a href="hapus.php?id=<?php echo $r['id']; ?>">Hapus</a>
		</td>
	</tr>
<?php  }
?>
		</tr>
	</table>
</center>