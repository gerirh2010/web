<?php 
session_start();
if (!isset($_SESSION['username'])) {
	header('location:../login.php');
}
include "koneksi.php";
$sql=mysqli_query($koneksi,"SELECT * FROM tb_sejarah WHERE id='".$_GET['id']."'");
$r=mysqli_fetch_array($sql);
?>
<center>
	<h2>Update Data</h2>
	<form method="POST" action="" enctype="multipart/form-data">
		<table border="3">
			<tr>
				<td>Masukkan Judul Artikel</td>
				<td>:</td>
				<td><input type="text" name="judul" value="<?php echo $r['judul'] ?>"></td>
			</tr>
			<tr>
				<td>Masukkan Deskripsi</td>
				<td>:</td>
				<td><textarea name="deskripsi"><?php echo $r['deskripsi']; ?></textarea></td>
			</tr>
			<tr>
				<td>Masukkan Gambar</td>
				<td>:</td>
				<td><input type="file" name="foto"></td>
			</tr>
			<tr>
				<td colspan="3"><center><img src="img/<?php echo $r['foto']; ?>" width="100" height="100"></center></td>
			</tr>
			<tr><td colspan="3"><center><input type="submit" name="update" value="Update"></center></td></tr>
		</table>
	</form>
</center>

<?php 
if (isset($_POST['update'])) {
 	$foto=$_FILES['foto']['name'];
 	$source=$_FILES['foto']['tmp_name'];
 	$folder='./foto/';

 	if ($foto !='') {
 		move_uploaded_file($source, $folder.$foto);
 		$sql=mysqli_query($koneksi,"UPDATE tb_sejarah SET judul='".$_POST['judul']."',deskripsi='".$_POST['deskripsi']."',foto='".$foto."' WHERE id='".$_GET['id']."'");
 	}
 	else{
 		$sql=mysqli_query($koneksi,"UPDATE tb_sejarah SET judul='".$_POST['judul']."',deskripsi='".$_POST['deskripsi']."' WHERE id='".$_GET['id']."'");
 	}
 	if ($sql) {
 		echo "Berhasil";
 		header("location:index.php");
 	}
 	else{
 		echo "Gagal";
 	}
 } 
 ?>